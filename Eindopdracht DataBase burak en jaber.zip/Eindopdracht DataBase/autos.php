<?php
session_start();

$successMessage = '';

if (isset($_GET['logout'])) {
    unset($_SESSION['email']);
    header('Location: homepage.php');
    exit();
}

$servername = "localhost:3307";
$username = "root";
$password = "";
$dbname = "register";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if (isset($_POST['add-to-cart'])) {
    $productDetails = $_POST['product-details'];
    $productId = $productDetails['product-id'];
    $productName = $productDetails['product-name'];
    $productPrice = $productDetails['product-price'];

    if (!isset($_SESSION['winkelwagen'])) {
        $_SESSION['winkelwagen'] = [];
    }

    $item = [
        'product-id' => $productId,
        'product-name' => $productName,
        'product-price' => $productPrice
    ];

    $_SESSION['winkelwagen'][] = $item;

    $successMessage = $productName . ' is toegevoegd aan je winkelwagen!';
}

$stmt = $conn->prepare("SELECT * FROM cars");
$stmt->execute();
$cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Autos</title>
    <link rel="stylesheet" href="autos.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
        function addToCart(productId, productName, productPrice) {
            var productDetails = {
                'product-id': productId,
                'product-name': productName,
                'product-price': productPrice
            };

            $.ajax({
                type: 'POST',
                url: 'winkelwagen.php',
                data: { 'add-to-cart': true, 'product-details': productDetails },
                success: function (response) {
                    console.log(response);
                    alert(productName + ' is toegevoegd aan je winkelwagen!');
                },
                error: function (error) {
                    console.error('Error adding to cart:', error);
                }
            });
        }
    </script>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-warning">
            <a class="navbar-brand" href="#">CAR DEALER</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="homepage.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="autos.php">Auto's</a>
                    </li>
                    <?php
                    if (isset($_SESSION['email'])) {
                        $username = explode('@', $_SESSION['email'])[0];

                        echo '<li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-user"></i> Welcome ' . $username . '
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="#">Account Settings</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="?logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                                    </div>
                                </li>';
                    } else {
                        echo '<li class="nav-item">
                                    <a class="nav-link" href="login.php">Login</a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" href="register.php">Register</a>
                                  </li>';
                    }
                    ?>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <div class="container">
            <?php
            if (!empty($successMessage)) {
                echo '<div class="alert alert-success" role="alert">' . $successMessage . '</div>';
            }

            foreach ($cars as $car): ?>
                <div class="product-box" data-product-id="<?php echo $car['car_id']; ?>">
                    <img src="<?php echo $car['image_url']; ?>" alt="Product Image">
                    <h2><?php echo $car['name']; ?></h2>
                    <p><?php echo $car['description']; ?></p>
                    <p><?php echo $car['rental_price']; ?> Euro p/d</p>
                    <a class="btn btn-primary" href="bestellen.php?car_id=' . $car['id'] . '&car_model=' . urlencode($car['name']) . '">Bestel</a>               </div>
            <?php endforeach; ?>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Car Dealer Autoverhuur</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>



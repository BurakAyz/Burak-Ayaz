<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit;
}

$host = 'localhost:3307';
$db = 'bestellen';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

if (isset($_POST["button"])) {
    $naam = $_POST["naam"];
    $adres = $_POST["adres"];
    $rijbewijsnummer = $_POST["rijbewijsnummer"];
    $telefoonnummer = $_POST["telefoonnummer"];
    $email = $_POST["email"];
    $start_date = $_POST["start_date"];
    $end_date = $_POST["end_date"];

    $car_id = $_POST["product_id"]; 

    $sql = "INSERT INTO formulier (naam, adres, rijbewijsnummer, telefoonnummer, email, start_date, end_date, car_id) 
            VALUES (:naam, :adres, :rijbewijsnummer, :telefoonnummer, :email, :start_date, :end_date, :car_id)";
    $stmt = $pdo->prepare($sql);

    $data = [
        'naam' => $naam,
        'adres' => $adres,
        'rijbewijsnummer' => $rijbewijsnummer,
        'telefoonnummer' => $telefoonnummer,
        'email' => $email,
        'start_date' => $start_date,
        'end_date' => $end_date,
        'car_id' => $car_id, 
    ];

    $stmt->execute($data);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bestellen</title>
    <link rel="stylesheet" href="bestellen.css">
</head>
<body>
    <form method="POST">
        <h2>Vul uw gegevens in:</h2>
    <select name="car_id" id="car_id">
            <option value="1">Audi RS6</option>
            <option value="2">BMW M3</option>
            <option value="3">Mercedes C63</option>
            <option value="4">Audi S7</option>
            <option value="5">Volkswagen Golf TCR</option>
            <option value="6">Volvo XC90</option>
            <option value="7">Lamborghini Urus</option>
            <option value="8">BMW E39</option>
            <option value="9">BMW M5</option>
            <option value="10">Volkswagen Up GTI</option>
            <option value="11">Honda HRV</option>
            <option value="12">Fiat Panda</option>
        </select>
        <input type="hidden" name="product_id" id="product_id" value="">
        <input type="text" name="naam" placeholder="Naam">
        <input type="text" name="adres" placeholder="Adres">
        <input type="text" name="rijbewijsnummer" placeholder="Rijbewijsnummer">
        <input type="text" name="telefoonnummer" placeholder="Telefoonnummer">
        <input type="text" name="email" placeholder="Email">
        <input type="date" name="start_date" placeholder="Start Datum">
        <input type="date" name="end_date" placeholder="Eind Datum">
        <input type="submit" name="button" value="Verzenden">
    </form>

    <script>
        document.querySelector('.add-to-cart').addEventListener('click', function() {
            document.getElementById('product_id').value = this.getAttribute('data-product-id');
        });
    </script>
</body>
</html>

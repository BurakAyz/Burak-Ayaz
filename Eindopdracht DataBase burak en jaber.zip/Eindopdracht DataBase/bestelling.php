<?php
session_start();

$successMessage = '';
$selectedCar = null;

$servername = "localhost:3307";
$username = "root";
$password = "";
$dbname = "bestellen";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (isset($_GET['car_id'], $_GET['car_model'])) {
        $selectedCar = ['id' => $_GET['car_id'], 'model' => urldecode($_GET['car_model'])];
    }

    if (isset($_POST['submit-order'])) {
        if ($selectedCar) {
            $data = [
                'naam' => ($_POST['naam']),
                'adres' => ($_POST['adres']),
                'rijbewijsnummer' => ($_POST['rijbewijsnummer']),
                'telefoonnummer' => ($_POST['telefoonnummer']),
                'email' => ($_POST['email']),
                'start_date' => ($_POST['start_date']),
                'end_date' => ($_POST['end_date']),
            ];

            $stmt = $conn->prepare("INSERT INTO formulier (naam, adres, rijbewijsnummer, telefoonnummer, email, start_date, end_date) 
            VALUES (:naam, :adres, :rijbewijsnummer, :telefoonnummer, :email, :start_date, :end_date)");
            $stmt->execute($data);

            $successMessage = 'Bestelling geplaatst voor ' . $selectedCar['model'];
        }
    }
} catch (PDOException $e) {
    $successMessage = 'Error: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bestellen</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="bestellen.css">
    <link rel="stylesheet" href="custom.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
    </style>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-warning">
            <a class="navbar-brand" href="#">CAR DEALER</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="homepage.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="autos.php">Auto's</a>
                    </li>
                    <?php
                    if (isset($_SESSION['email'])) {
                        $username = explode('@', $_SESSION['email'])[0];

                        echo '<li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-user"></i> Welcome ' . $username . '
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="#">Account Settings</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="?logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                                    </div>
                                </li>';
                    } else {
                        echo '<li class="nav-item">
                                    <a class="nav-link" href="login.php">Login</a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" href="register.php">Register</a>
                                  </li>';
                    }
                    ?>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <div class="container">
            <?php
            if ($selectedCar) {
                echo '<div class="selected-car">';
                echo '<h3>Geselecteerde Auto:</h3>';
                echo '<p>Model: ' . $selectedCar['model'] . '</p>';
                $stmt = $conn->prepare("SELECT image_url FROM cars WHERE id = :car_id");
                $stmt->bindParam(':car_id', $selectedCar['id']);
                $stmt->execute();
                $carImage = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($carImage) {
                    echo '<img src="' . $carImage['image_url'] . '" alt="' . $selectedCar['model'] . '" style="max-width: 70%; height: auto;">';
                }
                echo '</div>';
            }
            ?>

            <form action="bestellen.php" method="post">
                <label for="naam">Naam:</label>
                <input type="text" name="naam" required>

                <label for="adres">Adres:</label>
                <input type="text" name="adres" required>

                <label for="rijbewijsnummer">Rijbewijsnummer:</label>
                <input type="text" name="rijbewijsnummer" required>

                <label for="telefoonnummer">Telefoonnummer:</label>
                <input type="tel" name="telefoonnummer" required>

                <label for="email">E-mailadres:</label>
                <input type="email" name="email" required>

                <label for="start_date">Startdatum:</label>
                <input type="date" name="start_date" required>

                <label for="end_date">Einddatum:</label>
                <input type="date" name="end_date" required>

                <input type="submit" name="submit-order" value="Bestelling plaatsen">
            </form>

            <?php
            if ($successMessage) {
                echo '<div>';
                echo '<h4>' . $successMessage . '</h4>';
                echo '</div>';
            }
            ?>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Car Dealer Autoverhuur</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
    session_start();

    if (isset($_GET['logout'])) {
        unset($_SESSION['email']);
        header('Location: homepage.php'); 
        exit();
    }


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $_SESSION['email'] = $email; 

    if (isset($_POST['remember'])) {
        $token = bin2hex(random_bytes(32));


        setcookie('remember_token', $token, time() + (86400 * 30), "/"); 
    }

    header('Location: homepage.php');
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winkelmand</title>
    <link rel="stylesheet" href="homepage.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>

<header>
    <nav class="navbar navbar-expand-lg navbar-light bg-warning">
        <a class="navbar-brand" href="#">CAR DEALER</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="homepage.php">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="autos.php">Auto's</a>
                </li>

                <?php
                    if (isset($_SESSION['email'])) {
                        $username = explode('@', $_SESSION['email'])[0];
                        
                        echo '<li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-user"></i> Welcome ' . $username . '
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="#">Account Settings</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="?logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                                </div>
                              </li>';
                    } else {
                        echo '<li class="nav-item">
                                <a class="nav-link" href="login.php">Login</a>
                              </li>
                              <li class="nav-item">
                                <a class="nav-link" href="register.php">Register</a>
                              </li>';
                    }
                ?>
            </ul>
        </div>
    </nav>
</header>



    <div class="slideshow-container">
        <div class="mySlides fade">
            <div class="numbertext">1 / 3</div>
            <img src="m5.jpg" style="width:100%">
            <div class="text">BMW M5</div>
        </div>

        <div class="mySlides fade">
            <div class="numbertext">2 / 3</div>
            <img src="e39.jpg" style="width:100%">
            <div class="text">BMW E39</div>
        </div>

        <div class="mySlides fade">
            <div class="numbertext">3 / 3</div>
            <img src="s7.jpg" style="width:100%">
            <div class="text">AUDI S7</div>
        </div>

        <br>

        <div style="text-align:center">
            <span class="dot"></span>
            <span class="dot"></span>
            <span class="dot"></span>
        </div>
    </div>

    <main>
        <section class="car-gallery">
            <div class="car-image">
                <img src="rs6.jpg" alt="Audi RS6">
            </div>
            <div class="car-image">
                <img src="m3.jpg" alt="BMW M3">
            </div>
            <div class="car-image">
                <img src="c63.jpg" alt="Mercedes C63 AMG">
            </div>
        </section>
    </main>

    <footer>
        <div class="contact-info">
            <h2>Contact Information</h2>
            <p>Email: info@carrentals.com</p>
            <p>Phone: +123 456 7890</p>
            <p>Address: 123 Street, City, Country</p>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        let slideIndex = 0;
        showSlides();

        function showSlides() {
            let i;
            let slides = document.getElementsByClassName("mySlides");
            let dots = document.getElementsByClassName("dot");
            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
            }
            slideIndex++;
            if (slideIndex > slides.length) {
                slideIndex = 1
            }
            for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace(" active", "");
            }
            slides[slideIndex - 1].style.display = "block";
            dots[slideIndex - 1].className += " active";
            setTimeout(showSlides, 2000); 
        }
    </script>
</body>

</html>

<?php
session_start();

if (isset($_GET['logout'])) {
    $_SESSION = array();

    session_destroy();

    header("Location: register.php");
    exit;
}

function redirectToWinkelwagen() {
    header('Location: winkelwagen.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $servername = "localhost:3307";
    $username = "root";
    $password = "";
    $dbname = "register";

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $email = $_POST['email'];
        $password = $_POST['password'];

        $stmt = $conn->prepare('SELECT * FROM users WHERE email = :email');
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['email'] = $user['email'];
            $_SESSION['password'] = $user['password']; 

            echo '<div class="success-message"><i class="fas fa-check-circle"></i> Login successful! Redirecting to homepage...</div>';
            
            echo '<script>setTimeout(function() { window.location.href = "homepage.php"; }, 2000);</script>';
            exit; 
        } else {
            $error = 'Invalid email or password';
        }
    } catch (PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto Vloer</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="login.css">
    <link rel="stylesheet" href="custom.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-warning">
            <a class="navbar-brand" href="#">CAR DEALER</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="homepage.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="autos.php">Auto's</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="winkelwagen.php">Winkelwagen</a>
                    </li>
                    <?php
                    if (isset($_SESSION['email'])) {
                        $welcomeMessage = isset($_SESSION['name']) ? 'Welcome ' . $_SESSION['name'] : '';
                        echo '<li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" id="profileDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-user"></i> ' . $welcomeMessage . '
                                </a>
                                <div class="dropdown-menu" aria-labelledby="profileDropdown">
                                    <a class="dropdown-item" href="?logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                                </div>
                              </li>';
                    } else {
                        echo '<li class="nav-item">
                                <a class="nav-link" href="login.php">Login</a>
                              </li>
                              <li class="nav-item">
                                <a class="nav-link" href="register.php">Register</a>
                              </li>';
                    }
                    ?>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <section class="container">
            <h1>Login</h1>
            <?php
            if (isset($error)) {
                echo '<p class="error-message">' . htmlspecialchars($error) . '</p>';
            }
            ?>
            <form id="LoginForm" method="post" action="login.php">
                <input type="text" id="email" name="email" placeholder="Email" required>
                <input type="password" id="password" name="password" placeholder="Password" required>
                <button type="submit" name="login">Login</button>
            </form>
            <p>Don't have an account? <a href="register.php">Register</a></p>
        </section>
    </main>

    <footer>
        <p>&copy; 2022 Auto Vloer. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
</body>

</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto Vloer</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="register.css">
    <link rel="stylesheet" href="custom.css">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-warning">
            <a class="navbar-brand" href="#">CAR DEALER</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="autos.php">Autos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="winkelwagen.php">Winkelwagen</a>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <section class="container">
            <h1>Register</h1>

            <?php
                session_start();

                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $servername = "localhost:3307";
                    $username = "root";
                    $password = "";
                    $dbname = "register";

                    try {
                        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
                        $password = filter_var($_POST['password'], FILTER_SANITIZE_STRING);

                        $hashed_password = password_hash($password, PASSWORD_BCRYPT);

                        $sql = "INSERT INTO users (email, password) VALUES (?, ?)";
                        $stmt = $conn->prepare($sql);
                        $stmt->bindParam(1, $email);
                        $stmt->bindParam(2, $hashed_password);

                        if ($stmt->execute()) {
                            $_SESSION['register_success'] = true;
                            echo '<div class="success-message"><i class="fas fa-check-circle"></i> Registration successful! Redirecting to login...</div>';
                            echo '<script>setTimeout(function() { window.location.href = "login.php"; }, 2000);</script>';
                        } else {
                            echo '<div class="error-message">Error: ' . $stmt->errorInfo()[2] . '</div>';
                        }
                    } catch (PDOException $e) {
                        echo "Error: " . $e->getMessage();
                    }

                    $conn = null;
                }
            ?>

            <form id="registerForm" method="post" action="register.php">
                <input type="email" id="email" name="email" placeholder="Email" required>
                <input type="password" id="password" name="password" placeholder="Password" required>
                <button type="submit">Register</button>
            </form>

            <p>Already have an account? <a href="login.php">Login Here</a></p>
        </section>
    </main>

    <footer>
        <p>&copy; 2022 Auto Vloer. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
</body>
</html>

-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Gegenereerd op: 17 jan 2024 om 21:19
-- Serverversie: 10.4.28-MariaDB
-- PHP-versie: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `cars`
--

CREATE TABLE `cars` (
  `car_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `rental_price` decimal(10,2) NOT NULL,
  `image_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `cars`
--

INSERT INTO `cars` (`car_id`, `name`, `description`, `rental_price`, `image_url`) VALUES
(1, 'Audi Rs6', 'De epitome van sportiviteit en luxe, de Audi RS6 combineert een krachtige V8-motor met een verfijnd interieur, waardoor elke rit een adrenaline-gevulde ervaring wordt.', 650.00, 'rs6.jpg'),
(2, 'Bmw M3', 'De ultieme rijdersauto, de BMW M3, belichaamt pure dynamiek met zijn krachtige motor, sportieve ophanging en gestroomlijnd design.', 550.00, 'm3.jpg'),
(3, 'Mercedes C63', 'Een elegante krachtpatser op de weg, de Mercedes C63 straalt luxe uit en levert indrukwekkende prestaties dankzij zijn krachtige V8-motor.', 500.00, 'c63.jpg'),
(4, 'Audi S7', 'Sportiviteit ontmoet stijl in de Audi S7, met een krachtige motor, slank design en geavanceerde technologie voor een verfijnde rijervaring.', 275.00, 's7.jpg'),
(5, 'Volgswagen Golf TCR', 'De perfecte mix van prestaties en praktischheid, de Volkswagen Golf TCR biedt een sportieve rijervaring zonder compromissen.', 180.00, 'tcr.jpg'),
(6, 'Volvo XC90', 'De ultieme luxe SUV, de Volvo XC90, combineert Scandinavisch design met geavanceerde veiligheidsfuncties en een krachtige aandrijflijn.', 340.00, 'volvo.jpg'),
(7, 'Lamborghini Urus', 'Een symbool van buitengewone prestaties en ongeëvenaarde stijl, de Lamborghini Urus is een SUV met de ziel van een supercar.', 600.00, 'urus.jpg'),
(8, 'Bmw E39', 'Een icoon van de autogeschiedenis, de BMW E39, belichaamt tijdloze klasse en rijplezier met een perfecte balans tussen prestaties en comfort.', 225.00, 'e39.jpg'),
(9, 'Bmw M5', 'De BMW M5 is de belichaming van ultieme sportieve luxe, met een krachtige motor, precisiehandling en een luxueus interieur.', 525.00, 'm5.jpg'),
(10, 'Volgswagen Up GTI', 'Compact en pittig, de Volkswagen Up GTI biedt opwindende prestaties in een handzaam formaat, perfect voor stedelijke avonturen.', 100.00, 'up gti.jpg'),
(11, 'Honda Hrv', 'De Honda HRV combineert een sportief ontwerp met veelzijdigheid en efficiëntie, waardoor het een ideale keuze is voor avontuurlijke rijders.', 75.00, 'honda.jpg'),
(12, 'Fiat Panda', 'Compact en charmant, de Fiat Panda is een stadsauto met een speels karakter en efficiënte prestaties, perfect voor het verkennen van smalle straatjes.', 125.00, 'panda.jpg');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(1, '', 'burak@gmail.com', '$2y$10$qGEJPHxuujwtnD5r8BtX4ebNirMeovZ1733b0xUIe8TupEe9Al/va'),
(2, '', 'testaccount@gmail.com', '$2y$10$kBx6DdZbHl/N8c/NJDBSn.1a40c1FTd75sDkJe6m/0jpO72LHnAwK');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`car_id`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `cars`
--
ALTER TABLE `cars`
  MODIFY `car_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
